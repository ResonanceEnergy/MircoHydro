
# MicroHydroV1 Add-on GUI (macOS)
import os
import FreeCADGui as Gui

BASE = os.path.dirname(__file__)
MAC = os.path.join(BASE,'macros')
DRAW= os.path.join(BASE,'Drawings')
QA  = os.path.join(BASE,'QA')
SCR = os.path.join(BASE,'macros','scripts')

# helpers
def _run(path):
    if not os.path.exists(path):
        print('[MHV1][MISS]', path); return
    with open(path,'r',encoding='utf-8') as f:
        code=f.read()
    g={}
    try:
        exec(compile(code, path, 'exec'), g, g)
    except Exception as e:
        print('[MHV1][ERROR]', e)

class _Cmd_GenerateAll:
    def GetResources(self):
        return {'MenuText':'MHV1_GenerateAll','ToolTip':'Build all parts'}
    def IsActive(self): return True
    def Activated(self):
        _run(os.path.join(MAC,'01_Diffuser','build_diffuser.FCMacro'))
        _run(os.path.join(MAC,'02_Nozzle','build_nozzle.FCMacro'))
        _run(os.path.join(MAC,'03_VanePacks','build_vanepacks.FCMacro'))
        _run(os.path.join(MAC,'04_Retainer','build_retainer.FCMacro'))
        _run(os.path.join(MAC,'Assembly','build_assembly.FCMacro'))
        print('[MHV1] GenerateAll done')

class _Cmd_RunQA:
    def GetResources(self):
        return {'MenuText':'MHV1_RunQA','ToolTip':'Run geometry QA suite'}
    def IsActive(self): return True
    def Activated(self): _run(os.path.join(QA,'run_qa_suite.FCMacro'))

class _Cmd_ExportAll:
    def GetResources(self):
        return {'MenuText':'MHV1_ExportAll','ToolTip':'Export STEP/STL for all parts'}
    def IsActive(self): return True
    def Activated(self): _run(os.path.join(SCR,'export_all_formats.FCMacro'))

class _Cmd_GenDrawings:
    def GetResources(self):
        return {'MenuText':'MHV1_GenDrawings','ToolTip':'Generate TechDraw PDFs'}
    def IsActive(self): return True
    def Activated(self): _run(os.path.join(DRAW,'generate_drawings.FCMacro'))

def Initialize():
    Gui.addCommand('MHV1_GenerateAll', _Cmd_GenerateAll())
    Gui.addCommand('MHV1_RunQA',       _Cmd_RunQA())
    Gui.addCommand('MHV1_ExportAll',   _Cmd_ExportAll())
    Gui.addCommand('MHV1_GenDrawings', _Cmd_GenDrawings())
    print('[MHV1] Commands registered')
