# Salome UNV/MED
Import STEP from CFD/exports then mesh in Salome to UNV/MED.
