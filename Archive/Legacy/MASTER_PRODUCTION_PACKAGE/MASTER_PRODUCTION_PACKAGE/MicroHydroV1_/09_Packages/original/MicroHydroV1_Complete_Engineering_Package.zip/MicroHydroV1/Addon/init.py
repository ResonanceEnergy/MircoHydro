
# MicroHydroV1 FreeCAD Add-on init
# This file marks the directory as a FreeCAD module.
