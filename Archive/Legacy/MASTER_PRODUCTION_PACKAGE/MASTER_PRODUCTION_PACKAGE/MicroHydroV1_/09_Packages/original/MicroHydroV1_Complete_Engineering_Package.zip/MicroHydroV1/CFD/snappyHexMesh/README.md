# snappyHexMesh templates
Place STL in constant/triSurface and adjust dictionaries.
