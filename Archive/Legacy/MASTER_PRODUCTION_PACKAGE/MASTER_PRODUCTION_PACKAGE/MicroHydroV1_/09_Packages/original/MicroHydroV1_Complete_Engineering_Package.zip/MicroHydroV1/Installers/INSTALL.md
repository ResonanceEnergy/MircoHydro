
# Installer Instructions (System Mod Folder)

1) Close FreeCAD.
2) Copy the folder `MicroHydroV1/Addon` to: `<FreeCAD Installation>/Mod/MicroHydroV1/`.
3) Launch FreeCAD. Commands appear as:
   - MHV1_GenerateAll
   - MHV1_ExportAll
   - MHV1_RunQA
   - MHV1_GenDrawings
   - MHV1_ExportCFD
4) Open `CAD/params.json` to adjust dimensions, then run **Generate All Parts**.
