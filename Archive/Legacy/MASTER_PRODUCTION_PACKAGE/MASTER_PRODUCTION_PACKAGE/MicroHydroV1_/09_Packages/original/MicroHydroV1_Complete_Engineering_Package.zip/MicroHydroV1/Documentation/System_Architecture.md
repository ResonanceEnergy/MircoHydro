## System Architecture
Modular inlet + nozzle + vane packs; parametric CAD; automated test data pipeline.
