
# MicroHydroV1 Add-on GUI: registers toolbar & commands
import FreeCADGui as Gui
import os

class _MHV1_Cmd_GenerateAll:
    def GetResources(self):
        return {'Pixmap': os.path.join(os.path.dirname(__file__), 'icons', 'mhv1_generate.svg'),
                'MenuText': 'Generate All Parts',
                'ToolTip': 'Run MicroHydroV1 build_all macro'}
    def IsActive(self):
        return True
    def Activated(self):
        import FreeCAD as App
        mpath = os.path.join(os.path.dirname(__file__), 'macros', 'build_all.FCMacro')
        with open(mpath, 'r', encoding='utf-8') as f:
            code = f.read()
        exec(compile(code, mpath, 'exec'), {})

class _MHV1_Cmd_ExportAll:
    def GetResources(self):
        import os
        return {'Pixmap': os.path.join(os.path.dirname(__file__), 'icons', 'mhv1_export.svg'),
                'MenuText': 'Export ALL CAD',
                'ToolTip': 'Export STEP/STL/IGES/BREP for all parts'}
    def IsActive(self):
        return True
    def Activated(self):
        import os
        mpath = os.path.join(os.path.dirname(__file__), 'macros', 'scripts', 'export_all_formats.FCMacro')
        with open(mpath, 'r', encoding='utf-8') as f:
            code = f.read()
        exec(compile(code, mpath, 'exec'), {})

class _MHV1_Cmd_RunQA:
    def GetResources(self):
        import os
        return {'Pixmap': os.path.join(os.path.dirname(__file__), 'icons', 'mhv1_qa.svg'),
                'MenuText': 'Run QA Suite',
                'ToolTip': 'Run geometry QA checks'}
    def IsActive(self):
        return True
    def Activated(self):
        import os
        qapath = os.path.join(os.path.dirname(__file__), '..', 'QA', 'run_qa_suite.FCMacro')
        qapath = os.path.normpath(qapath)
        with open(qapath, 'r', encoding='utf-8') as f:
            code = f.read()
        exec(compile(code, qapath, 'exec'), {})

class _MHV1_Cmd_GenDrawings:
    def GetResources(self):
        import os
        return {'Pixmap': os.path.join(os.path.dirname(__file__), 'icons', 'mhv1_drawings.svg'),
                'MenuText': 'Generate Drawings',
                'ToolTip': 'Auto-generate TechDraw sheets and export PDF/DXF'}
    def IsActive(self):
        return True
    def Activated(self):
        import os
        mpath = os.path.join(os.path.dirname(__file__), '..', 'Drawings', 'generate_drawings.FCMacro')
        mpath = os.path.normpath(mpath)
        with open(mpath, 'r', encoding='utf-8') as f:
            code = f.read()
        exec(compile(code, mpath, 'exec'), {})

class _MHV1_Cmd_ExportCFD:
    def GetResources(self):
        import os
        return {'Pixmap': os.path.join(os.path.dirname(__file__), 'icons', 'mhv1_cfd.svg'),
                'MenuText': 'Export CFD Mesh',
                'ToolTip': 'Prepare STL/UNV/MED for CFD'}
    def IsActive(self):
        return True
    def Activated(self):
        import os
        mpath = os.path.join(os.path.dirname(__file__), '..', 'CFD', 'export_cfd_mesh.FCMacro')
        mpath = os.path.normpath(mpath)
        with open(mpath, 'r', encoding='utf-8') as f:
            code = f.read()
        exec(compile(code, mpath, 'exec'), {})

Gui.addCommand('MHV1_GenerateAll', _MHV1_Cmd_GenerateAll())
Gui.addCommand('MHV1_ExportAll', _MHV1_Cmd_ExportAll())
Gui.addCommand('MHV1_RunQA', _MHV1_Cmd_RunQA())
Gui.addCommand('MHV1_GenDrawings', _MHV1_Cmd_GenDrawings())
Gui.addCommand('MHV1_ExportCFD', _MHV1_Cmd_ExportCFD())

# Create toolbar
mw = Gui.getMainWindow()
wb = Gui.getWorkbench('PartWorkbench') if Gui.activeWorkbench() else None

# Add a custom toolbar
try:
    tb = mw.findChild(type(mw.__class__), 'MicroHydroV1')
except Exception:
    tb = None

# The command registration is enough for the user to add to any workbench or use search.
