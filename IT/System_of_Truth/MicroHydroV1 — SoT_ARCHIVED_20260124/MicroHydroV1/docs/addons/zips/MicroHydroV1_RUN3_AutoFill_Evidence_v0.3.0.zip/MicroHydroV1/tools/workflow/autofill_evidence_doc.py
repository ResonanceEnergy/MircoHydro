#!/usr/bin/env python3
"""MicroHydroV1 - Auto-fill RUN-3 Evidence Doc

What this does
- Reads T-002 timeseries CSV (Time_s, Pressure_Pa)
- Computes:
  - inferred sampling rate (fs)
  - PSD peakiness = max(PSD)/median(PSD) in 0.2–20 Hz
  - dominant frequency in that band
- Generates PSD plot PNG (optional)
- Auto-fills docs/run3/RUN3_Evidence_Template.docx and writes a populated docx

Usage
  python tools/workflow/autofill_evidence_doc.py     --root .     --run-id 2026-01-22_RUN3     --t002 tests/raw/RUN3/T002_TankRipple_timeseries.csv     --out-doc docs/run3/RUN3_Evidence_2026-01-22_RUN3.docx     --out-plot tests/results/summary/T002_PSD_Peakiness.png

"""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document

BAND_LOW = 0.2
BAND_HIGH = 20.0


def compute_psd(x: np.ndarray, fs: float):
    x = x - np.nanmean(x)
    try:
        from scipy.signal import welch
        f, pxx = welch(x, fs=fs, nperseg=min(2048, len(x)))
    except Exception:
        n = len(x)
        win = np.hanning(n)
        xf = np.fft.rfft(x * win)
        pxx = (np.abs(xf) ** 2) / (fs * np.sum(win ** 2))
        f = np.fft.rfftfreq(n, d=1.0 / fs)
    return f, pxx


def peakiness_metrics(csv_path: Path, time_col='Time_s', signal_col='Pressure_Pa'):
    df = pd.read_csv(csv_path)
    if time_col not in df.columns or signal_col not in df.columns:
        raise SystemExit(f"Missing columns. Need {time_col} and {signal_col}. Got: {list(df.columns)}")

    t = pd.to_numeric(df[time_col], errors='coerce').to_numpy()
    x = pd.to_numeric(df[signal_col], errors='coerce').to_numpy()
    m = np.isfinite(t) & np.isfinite(x)
    t, x = t[m], x[m]
    if len(t) < 10:
        raise SystemExit('Not enough samples after cleaning.')

    dtv = np.diff(t)
    dtv = dtv[np.isfinite(dtv) & (dtv > 0)]
    fs = 1.0 / float(np.median(dtv)) if len(dtv) else 100.0

    f, pxx = compute_psd(x, fs)
    band = (f >= BAND_LOW) & (f <= BAND_HIGH)
    if not np.any(band):
        raise SystemExit('No PSD bins in band. Check sampling/timebase.')

    p = pxx[band]
    peak = float(np.max(p))
    med = float(np.median(p))
    peakiness = peak / max(1e-12, med)
    f_dom = float(f[band][np.argmax(p)])

    return {
        'fs': fs,
        'peakiness': peakiness,
        'f_dom': f_dom,
        'peak_psd': peak,
        'median_psd': med,
    }


def replace_in_paragraph(paragraph, mapping: dict[str, str]):
    # simple full-text replace on paragraph runs
    for key, val in mapping.items():
        if key in paragraph.text:
            for run in paragraph.runs:
                run.text = run.text.replace(key, val)


def fill_table_values(doc: Document, peakiness: str, f_dom: str):
    # Look for the results table and update cells where appropriate.
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if len(cells) < 6:
                continue
            test, metric = cells[0], cells[1]
            # Resonance row
            if test.replace('‑','-').startswith('T') and 'Resonance' in metric:
                # Result column index 3
                row.cells[3].text = peakiness
            # If there's a place to record dominant Hz, put it in Evidence link or Notes if present.
            if test.replace('‑','-').startswith('T') and metric.lower().startswith('ripple'):
                # optionally append dominant Hz to result cell if it's blank
                if row.cells[3].text.strip() in ('____','', '____ '):
                    row.cells[3].text = f"{row.cells[3].text.strip()}"


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='MicroHydroV1 root')
    ap.add_argument('--run-id', required=True)
    ap.add_argument('--t002', required=True, help='Path to T-002 timeseries CSV')
    ap.add_argument('--out-doc', required=True, help='Output populated docx')
    ap.add_argument('--template', default='docs/run3/RUN3_Evidence_Template.docx')
    ap.add_argument('--out-plot', default=None, help='Optional: output plot PNG by calling plot script')
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    t002_path = Path(args.t002)
    if not t002_path.is_absolute():
        t002_path = root / t002_path

    metrics = peakiness_metrics(t002_path)
    peakiness = f"{metrics['peakiness']:.3f}"
    f_dom = f"{metrics['f_dom']:.2f}"
    fs = f"{metrics['fs']:.2f}"

    # optional plot
    if args.out_plot:
        plot_script = root/'tools/plots/plot_t002_psd_peakiness.py'
        if plot_script.exists():
            import subprocess
            out_plot = Path(args.out_plot)
            if not out_plot.is_absolute():
                out_plot = root/out_plot
            out_plot.parent.mkdir(parents=True, exist_ok=True)
            subprocess.check_call(['python', str(plot_script), '--csv', str(t002_path), '--out', str(out_plot)])

    template = root / args.template
    if not template.exists():
        raise SystemExit('Template not found: ' + str(template))

    doc = Document(str(template))
    now = dt.datetime.now().isoformat(timespec='seconds')

    mapping = {
        '{{RUN_ID}}': args.run_id,
        '{{DATETIME}}': now,
        '{{PEAKINESS}}': peakiness,
        '{{F_DOM}}': f_dom,
        'Observed dominant peak (Hz): ____': f"Observed dominant peak (Hz): {f_dom}",
        'Sampling: 100 Hz': f"Sampling: 100 Hz (inferred fs≈{fs} Hz)",
    }

    for p in doc.paragraphs:
        replace_in_paragraph(p, mapping)

    fill_table_values(doc, peakiness=peakiness, f_dom=f_dom)

    out_doc = Path(args.out_doc)
    if not out_doc.is_absolute():
        out_doc = root/out_doc
    out_doc.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_doc))

    print('Wrote:', out_doc)
    print('T-002 peakiness:', peakiness, 'dominant Hz:', f_dom, 'fs≈', fs)


if __name__ == '__main__':
    main()
