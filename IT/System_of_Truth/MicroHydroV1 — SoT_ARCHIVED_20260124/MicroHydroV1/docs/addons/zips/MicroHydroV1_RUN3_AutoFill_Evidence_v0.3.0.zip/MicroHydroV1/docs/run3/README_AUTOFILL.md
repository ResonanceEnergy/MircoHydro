# Auto-fill Evidence Doc (RUN-3)

## What it does
- Computes T-002 resonance peakiness (max/median PSD in 0.2–20 Hz)
- Computes dominant frequency in that band
- Fills the Evidence Template docx and saves a populated docx
- Optionally generates the PSD plot PNG

## Command
```bash
python tools/workflow/autofill_evidence_doc.py   --root .   --run-id 2026-01-22_RUN3   --t002 tests/raw/RUN3/T002_TankRipple_timeseries.csv   --out-doc docs/run3/RUN3_Evidence_2026-01-22_RUN3.docx   --out-plot tests/results/summary/T002_PSD_Peakiness.png
```
