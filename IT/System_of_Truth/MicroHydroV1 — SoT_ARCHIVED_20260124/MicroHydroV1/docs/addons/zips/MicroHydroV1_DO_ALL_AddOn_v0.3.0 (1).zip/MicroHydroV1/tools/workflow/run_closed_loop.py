#!/usr/bin/env python3
"""MicroHydroV1 - Closed-loop automation (local workstation).

What this does:
1) Run optimizer to propose params_optimized.json using the LOCKED-IN resonance metric:
   - T-002 PSD peakiness = max(PSD)/median(PSD) in 0.2-20 Hz band.
2) Prompt you to run FreeCAD macro build_all.FCMacro to regenerate CAD exports.
3) Run measurements importer (CSV -> RnD workbook).
4) Create Release ZIP with MANIFEST.json.

Usage:
  python tools/workflow/run_closed_loop.py --root . --version v0.3.0 --date 2026-01-22     --optimize --resonance-csv tests/raw/<run>/T002_timeseries.csv --signal-col Pressure_Pa --time-col Time_s     --import --release

"""

from __future__ import annotations

import argparse
import subprocess
from pathlib import Path


def run(cmd: list[str]):
    print('[RUN]', ' '.join(cmd))
    subprocess.check_call(cmd)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='MicroHydroV1 root folder')
    ap.add_argument('--version', required=True)
    ap.add_argument('--date', required=True)

    ap.add_argument('--optimize', action='store_true')
    ap.add_argument('--resonance-csv', default=None)
    ap.add_argument('--signal-col', default='Pressure_Pa')
    ap.add_argument('--time-col', default='Time_s')
    ap.add_argument('--fs', type=float, default=None)

    ap.add_argument('--import', dest='do_import', action='store_true')
    ap.add_argument('--release', dest='do_release', action='store_true')

    args = ap.parse_args(argv)
    root = Path(args.root).resolve()

    if args.optimize:
        opt = root/'tools/optimize/optimize_params.py'
        cfg = root/'tools/optimize/opt_config.json'
        inp = root/'cad/params/params.json'
        outp = root/'cad/params/params_optimized.json'
        cmd = ['python', str(opt), '--params', str(inp), '--config', str(cfg), '--out', str(outp)]
        if args.resonance_csv:
            cmd += ['--resonance-csv', str(Path(args.resonance_csv))]
            cmd += ['--signal-col', args.signal_col]
            if args.time_col:
                cmd += ['--time-col', args.time_col]
            if args.fs:
                cmd += ['--fs', str(args.fs)]
        run(cmd)
        print('
[NEXT] Review params_optimized.json. If acceptable, copy it over params.json (with change note) and run FreeCAD:')
        print('       FreeCAD GUI -> Macro -> Macros -> cad/macros/build_all.FCMacro')

    if args.do_import:
        imp = root/'automation/import_measurements.py'
        wb = root/'automation/MicroHydroV1_RnD_Export.xlsx'
        cfg = root/'automation/Import_Config.json'
        csvs = sorted(str(p) for p in (root/'tests/raw').rglob('*.csv'))
        if csvs and imp.exists():
            run(['python', str(imp), '--workbook', str(wb), '--config', str(cfg), '--csv', *csvs])
        else:
            print('[WARN] Import step skipped (importer missing or no CSVs).')

    if args.do_release:
        mk = root/'tools/release/make_release.py'
        if mk.exists():
            run(['python', str(mk), '--root', str(root), '--version', args.version, '--date', args.date, '--out', str(root/'dist')])
        else:
            print('[WARN] Release tool missing:', mk)

    print('[DONE]')


if __name__ == '__main__':
    main()
