# Power Automate Blueprints - MicroHydroV1 (SoT -> Review -> Release)

These flows automate *governance and routing* in SharePoint. They do **not** execute FreeCAD or local Python (those run on your workstation/VM).

## Flow A: New Raw Data Arrives (tests/raw)
**Trigger:** When a file is created in folder `tests/raw/` (or `tests/raw/*` depending on connector limitations).

**Actions:**
1. Set metadata on the uploaded CSV:
   - Artifact Type = TestData
   - Status = Draft
   - Stage = B or C (depending on test)
2. Post a Teams message (or email) with:
   - file link
   - inferred run folder
   - next action checklist
3. Create a Planner task (or To Do task):
   - Title: `Import measurements for <RunFolder>`
   - Checklist:
     - Run importer
     - Review Dashboard
     - Attach evidence plot

## Flow B: Workbook Updated -> Request Review
**Trigger:** When file `automation/MicroHydroV1_RnD_Export.xlsx` is modified.

**Actions:**
1. Set Status = Review
2. Notify Teams channel
3. Create/Update a log entry (SharePoint List) with:
   - date/time
   - rows imported (paste from script output)

## Flow C: Release Candidate Gate
**Trigger:** When key artifacts are set to Approved (Content Approval or Status column):
- Master doc
- STW Matrix
- Key evidence plots

**Actions:**
1. Create a task: `Cut Release v0.3.0`
2. Populate Release ID metadata on candidate items
3. Notify: `Ready to run tools/run_pipeline.py --release`
