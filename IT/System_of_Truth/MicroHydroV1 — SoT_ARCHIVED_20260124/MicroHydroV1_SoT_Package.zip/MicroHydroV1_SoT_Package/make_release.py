#!/usr/bin/env python3
"""MicroHydroV1 - Create an immutable Release bundle.

What it does
1) Collects deliverables and evidence by folders
2) Writes a MANIFEST.json with SHA256 hashes
3) Creates ZIP: MicroHydroV1_Release_vX.Y.Z_YYYY-MM-DD.zip

Usage
    python make_release.py --root /path/to/MicroHydroV1 --version v0.2.0 --date 2026-01-22 --out dist
"""

from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

DEFAULT_INCLUDE = [
    'docs/master',
    'docs/procedures',
    'docs/reports',
    'docs/governance',
    'cad/params',
    'cad/macros',
    'tests/results',
    'data/reference',
]


def sha256_file(path: Path, chunk=1024*1024) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def iter_files(root: Path, rel_dir: str):
    base = root / rel_dir
    if not base.exists():
        return
    for p in base.rglob('*'):
        if p.is_file() and p.name not in ('.gitkeep',):
            yield p


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='Path to MicroHydroV1 SoT root')
    ap.add_argument('--version', required=True, help='Release version, e.g., v0.2.0')
    ap.add_argument('--date', required=True, help='Release date YYYY-MM-DD')
    ap.add_argument('--out', default='dist', help='Output folder')
    ap.add_argument('--include', nargs='*', default=DEFAULT_INCLUDE, help='Relative folders to include')
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    zip_name = out_dir / f"MicroHydroV1_Release_{args.version}_{args.date}.zip"

    manifest = {
        'project': 'MicroHydroV1',
        'version': args.version,
        'date': args.date,
        'files': []
    }

    to_add = []
    for rel in args.include:
        for p in iter_files(root, rel):
            to_add.append((p, p.relative_to(root).as_posix()))

    for p, relpath in sorted(to_add, key=lambda x: x[1]):
        manifest['files'].append({
            'path': relpath,
            'bytes': p.stat().st_size,
            'sha256': sha256_file(p)
        })

    with zipfile.ZipFile(zip_name, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p, relpath in to_add:
            z.write(p, arcname=relpath)
        z.writestr('MANIFEST.json', json.dumps(manifest, indent=2))

    print('Created:', zip_name)
    print('Manifest entries:', len(manifest['files']))


if __name__ == '__main__':
    main()
