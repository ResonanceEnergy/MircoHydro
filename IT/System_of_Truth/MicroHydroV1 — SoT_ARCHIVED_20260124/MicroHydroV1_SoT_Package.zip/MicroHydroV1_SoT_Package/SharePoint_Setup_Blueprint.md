# MicroHydroV1 - SharePoint SoT / Releases / Archive Setup Blueprint (Operational)

This blueprint turns the repo skeleton into a SharePoint-first configuration management system with 3 libraries:

- MicroHydroV1 - SoT (Working): only editable workspace
- MicroHydroV1 - Releases (Immutable): read-only tags / milestones
- MicroHydroV1 - Archive (Read-Only): legacy / deprecated

## A. Create the 3 document libraries
1. Create MicroHydroV1 - SoT
2. Create MicroHydroV1 - Releases
3. Create MicroHydroV1 - Archive

## B. SoT: Folder skeleton (upload/extract)
Create the folder structure below in SoT (matches the repo skeleton):

- docs/ (master, procedures, reports, templates, governance)
- cad/ (params, macros, exports)
- automation/
- tests/ (raw, processed, results)
- data/ (reference, runs)
- tools/ (validate, release)
- workspace/ (scratch; optional)

### Recommended structure details
- cad/exports/ and tests/results/ are generated and should be treated as non-canonical outputs.
- Canonical parameter control lives at cad/params/params.json.

## C. SoT library settings
### Versioning
- Enable Major and Minor versions
- Enable Content Approval (Approved = Published)
- Keep version history depth high (e.g., 200)

### Selective required checkout (high-risk files)
Require checkout only for:
- cad/params/params.json
- automation/import_measurements.py
- docs/master/*

## D. Metadata columns (recommended)
Create these columns on SoT and Releases (Archive optional):

- Artifact Type (Choice): MasterDoc, STWMatrix, CADParams, ImporterScript, RnDWorkbook, TestProcedure, EvidencePlot, CADMacro, TestData, ReleaseBundle
- Stage (Choice): A, B, C, D, E
- Status (Choice): Draft, Review, Approved, Obsolete
- Source of Truth (Yes/No)
- Version Tag (Text): e.g., v0.3.1
- Release ID (Text): e.g., R-2026-01-22

## E. Required views
Create these views in SoT:

1. Source of Truth: Filter Source of Truth = Yes AND Status != Obsolete
2. Needs Review: Filter Status = Review
3. Obsolete: Filter Status = Obsolete

## F. Workflow (Draft -> Review -> Publish)
- Draft: edit normally, minor versions increment
- Review: set Status = Review
- Publish: approve to create a major version; set Status = Approved and update Version Tag

## G. Releases workflow
- Create a release ZIP named: MicroHydroV1_Release_vX.Y.Z_YYYY-MM-DD.zip
- Upload ZIP to Releases library with Version Tag and Release ID
- Never edit files in Releases; create a new release for changes

## H. Archive workflow
- Move deprecated content into Archive
- Set Status = Obsolete and Source of Truth = No

## I. Operational checklists
### Daily checklist
- New test data: create tests/raw/YYYY-MM-DD_RunN_shortdesc/, upload raw CSVs (never overwrite)
- High-risk edits: checkout -> edit -> set Review -> approve to publish
- Releases: collect Approved artifacts + evidence, create ZIP, upload to Releases
