# MicroHydroV1 - Operational SOP (SharePoint-First)

## 1) Purpose
This SOP defines how MicroHydroV1 assets are controlled in SharePoint using a 3-library model (SoT / Releases / Archive), plus the working folder skeleton for tests, CAD, automation, and documentation.

## 2) Libraries
### 2.1 SoT (Working)
- The only editable workspace.
- Contains canonical files and project structure.

### 2.2 Releases (Immutable)
- Frozen, read-only release bundles.
- Changes require a new release.

### 2.3 Archive (Read-Only)
- Legacy content preserved for provenance.

## 3) Foldering & canonical rules
- Canonical CAD parameters: cad/params/params.json
- Canonical importer: automation/import_measurements.py
- Master narrative: docs/master/
- Raw test data: tests/raw/YYYY-MM-DD_RunN_shortdesc/ (never overwrite)
- Generated outputs: cad/exports/ and tests/results/ (treat as generated; include in Releases as evidence when needed)

## 4) Metadata & views
Apply the library metadata schema from SharePoint_Columns_Schema.json and create the standard views:
- Source of Truth
- Needs Review
- Obsolete

## 5) Change control for high-risk artifacts
High-risk artifacts require checkout + approval:
- params.json
- importer script
- master docs

## 6) Test data ingestion procedure
1. Create a new run folder under tests/raw/.
2. Upload raw CSVs (never overwrite; use suffixes like _v2 if corrected).
3. Run the importer to append into the canonical workbook.
4. Store evidence plots under tests/results/summary/ and drawings under tests/results/drawings/.

## 7) Release procedure
1. Validate SoT structure using validate_repo.py.
2. Ensure required artifacts are Approved.
3. Run make_release.py to create a ZIP + MANIFEST.
4. Upload ZIP to Releases library with Version Tag / Release ID.

## 8) Archival procedure
Move deprecated items to Archive and mark them Obsolete; do not use them in active decisions unless re-promoted.
