#!/usr/bin/env python3
"""Phase 4 orchestrator.

Runs:
1) compute_run_metrics.py -> docs/runN/<Version>_Metrics_<RunID>.json
2) build_run_report_html.py -> docs/runN/<Version>_Report_<RunID>.html
3) writes sidecar JSON next to latest dist ZIP: dist/<ZipName>.metrics.json
4) optional: copies ZIP + metrics JSON into a synced Releases folder (macOS), if MICROHYDRO_RELEASES_SYNC_PATH is set.
5) optional: opens dist/ and Releases URL.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import os
import json
import re

def run(cmd: list[str]):
    print('[RUN]', ' '.join(cmd))
    subprocess.check_call(cmd)


def find_latest_zip(dist: Path):
    zips = sorted(dist.glob('*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
    return zips[0] if zips else None


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    ap.add_argument('--run-id', required=True)
    ap.add_argument('--t002', default=None)
    ap.add_argument('--workbook', default='automation/MicroHydroV1_RnD_Export.xlsx')
    ap.add_argument('--dist', default='dist')
    ap.add_argument('--open', dest='do_open', action='store_true', help='Open dist and Releases URL after completion')
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    run_id = args.run_id

    # infer run number
    m = re.search(r'Run(\d+)', run_id, re.IGNORECASE)
    run_num = m.group(1) if m else 'X'
    version = f"RUN{run_num}" if m else 'RUN'

    scripts = root/'scripts'/'phase4'
    metrics_out = root/'docs'/f'run{run_num}'/f'{version}_Metrics_{run_id}.json'

    # 1) metrics
    cmd = ['python3', str(scripts/'compute_run_metrics.py'), '--root', str(root), '--run-id', run_id, '--workbook', str(root/args.workbook)]
    if args.t002:
        cmd += ['--t002', args.t002]
    run(cmd)

    if not metrics_out.exists():
        raise SystemExit('Expected metrics file not found: ' + str(metrics_out))

    # 2) HTML report
    run(['python3', str(scripts/'build_run_report_html.py'), '--root', str(root), '--metrics', str(metrics_out)])

    # 3) sidecar JSON next to latest ZIP
    dist = root/args.dist
    dist.mkdir(parents=True, exist_ok=True)
    latest = find_latest_zip(dist)
    if latest:
        sidecar = dist/(latest.name + '.metrics.json')
        # store same metrics payload
        sidecar.write_text(metrics_out.read_text(encoding='utf-8'), encoding='utf-8')
        print('Wrote sidecar:', sidecar)

        # 4) copy into synced Releases folder
        sync_path = os.environ.get('MICROHYDRO_RELEASES_SYNC_PATH','').strip()
        if sync_path:
            sp = Path(sync_path).expanduser()
            sp.mkdir(parents=True, exist_ok=True)
            for f in (latest, sidecar):
                dest = sp/f.name
                dest.write_bytes(f.read_bytes())
                print('Copied to Releases sync:', dest)

    else:
        print('[WARN] No ZIP found in dist/. Sidecar JSON not created.')

    # 5) open convenience
    if args.do_open:
        try:
            subprocess.call(['open', str(dist)])
            url = os.environ.get('MICROHYDRO_RELEASES_URL','').strip()
            if url:
                subprocess.call(['open', url])
        except Exception:
            pass

    print('[DONE] Phase 4 complete.')


if __name__ == '__main__':
    main()
