#!/usr/bin/env python3
"""Compute per-run metrics and classification.

Reads:
- `automation/MicroHydroV1_RnD_Export.xlsx` (Measurements sheet)
- T-002 timeseries CSV (Time_s, Pressure_Pa)

Outputs:
- a metrics JSON for the run

Classification rules (solo mode):
- PASS if all acceptance criteria pass
- WATCH if any criterion missing/ambiguous OR resonance peakiness is high
- FAIL if any criterion fails

Acceptance criteria are encoded to match project specs.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import json
import re
import datetime as dt
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

BAND_LOW = 0.2
BAND_HIGH = 20.0

# Acceptance thresholds
T001_MIN = 0.90
T002_FACTOR = 0.70
T003_MAX = 0.10
T004_MIN = 10.0
T004_MAX = 12.0


def _safe_float(x) -> Optional[float]:
    try:
        if x is None or x == '':
            return None
        return float(x)
    except Exception:
        return None


def compute_psd(x: np.ndarray, fs: float):
    x = x - np.nanmean(x)
    try:
        from scipy.signal import welch
        f, pxx = welch(x, fs=fs, nperseg=min(2048, len(x)))
    except Exception:
        n = len(x)
        win = np.hanning(n)
        xf = np.fft.rfft(x * win)
        pxx = (np.abs(xf) ** 2) / (fs * np.sum(win ** 2))
        f = np.fft.rfftfreq(n, d=1.0/fs)
    return f, pxx


def peakiness_metrics(csv_path: Path, time_col='Time_s', signal_col='Pressure_Pa'):
    df = pd.read_csv(csv_path)
    if time_col not in df.columns or signal_col not in df.columns:
        raise SystemExit(f"Missing columns in {csv_path}. Need {time_col} and {signal_col}.")
    t = pd.to_numeric(df[time_col], errors='coerce').to_numpy()
    x = pd.to_numeric(df[signal_col], errors='coerce').to_numpy()
    m = np.isfinite(t) & np.isfinite(x)
    t, x = t[m], x[m]
    dtv = np.diff(t)
    dtv = dtv[np.isfinite(dtv) & (dtv > 0)]
    fs = 1.0 / float(np.median(dtv)) if len(dtv) else 100.0
    f, pxx = compute_psd(x, fs)
    band = (f >= BAND_LOW) & (f <= BAND_HIGH)
    pband = pxx[band]
    peak = float(np.max(pband))
    med = float(np.median(pband))
    peakiness = peak / max(1e-12, med)
    dom = float(f[band][np.argmax(pband)])
    return {
        'fs_est_hz': float(fs),
        't002_peakiness': float(peakiness),
        't002_dominant_hz': float(dom),
    }


def read_measurements_for_run(workbook_path: Path, run_id: str) -> Dict[str, Dict[str, Any]]:
    """Return latest per Test_ID within the specified Run_ID.

If Run_ID column is missing, returns latest overall per Test_ID (warns upstream).
"""
    import openpyxl
    wb = openpyxl.load_workbook(workbook_path, data_only=True)
    if 'Measurements' not in wb.sheetnames:
        raise SystemExit('Workbook missing Measurements sheet.')
    ws = wb['Measurements']

    # header map
    headers = {}
    for c in range(1, ws.max_column + 1):
        v = ws.cell(1, c).value
        if v:
            headers[str(v).strip()] = c

    def col(name):
        return headers.get(name)

    idx_ts = col('Timestamp')
    idx_tid = col('Test_ID')
    idx_sensor = col('Sensor')
    idx_val = col('Value')
    idx_unit = col('Unit')
    idx_base = col('Baseline_Value')
    idx_run = col('Run_ID')

    if not all([idx_ts, idx_tid, idx_sensor, idx_val]):
        raise SystemExit('Measurements sheet missing required headers.')

    def parse_ts(x):
        if x is None or x == '':
            return None
        if isinstance(x, dt.datetime):
            return x
        try:
            return dt.datetime.fromisoformat(str(x))
        except Exception:
            try:
                return pd.to_datetime(x).to_pydatetime()
            except Exception:
                return None

    best = {}
    run_col_missing = idx_run is None

    for r in range(2, ws.max_row + 1):
        tid = ws.cell(r, idx_tid).value
        if not tid:
            continue
        tid = str(tid).replace('‑','-').strip()
        if tid not in ('T-001','T-002','T-003','T-004'):
            continue

        # filter by run
        if idx_run is not None:
            rid = ws.cell(r, idx_run).value
            if str(rid).strip() != run_id:
                continue

        ts = parse_ts(ws.cell(r, idx_ts).value)
        sensor = ws.cell(r, idx_sensor).value
        val = ws.cell(r, idx_val).value
        unit = ws.cell(r, idx_unit).value if idx_unit else ''
        base = ws.cell(r, idx_base).value if idx_base else None

        rec = {
            'timestamp': ts,
            'sensor': sensor,
            'value': val,
            'unit': unit,
            'baseline': base,
        }

        if tid not in best:
            best[tid] = rec
        else:
            ots = best[tid].get('timestamp')
            if ts and (ots is None or ts > ots):
                best[tid] = rec

    best['_run_col_missing'] = run_col_missing
    return best


def classify(m: Dict[str, Any]):
    issues = []

    c = _safe_float(m.get('t001_coherence'))
    if c is None:
        issues.append('T-001 missing')
    elif c < T001_MIN:
        issues.append('T-001 FAIL')

    r = _safe_float(m.get('t002_ripple_mm'))
    b = _safe_float(m.get('t002_baseline_mm'))
    if r is None or b is None or b <= 0:
        issues.append('T-002 missing baseline/value')
    else:
        if r > T002_FACTOR * b:
            issues.append('T-002 FAIL')

    d = _safe_float(m.get('t003_drift_hz'))
    if d is None:
        issues.append('T-003 missing')
    elif d > T003_MAX:
        issues.append('T-003 FAIL')

    p = _safe_float(m.get('t004_power_kw'))
    if p is None:
        issues.append('T-004 missing')
    elif not (T004_MIN <= p <= T004_MAX):
        issues.append('T-004 FAIL')

    peak = _safe_float(m.get('t002_peakiness'))
    if peak is None:
        issues.append('Peakiness missing')
    else:
        # heuristic: WATCH if peakiness > 2.0
        if peak > 2.0:
            issues.append('Resonance WATCH (peakiness high)')

    # decide
    hard_fail = any('FAIL' in x for x in issues)
    if hard_fail:
        status = 'FAIL'
    elif len(issues) == 0:
        status = 'PASS'
    else:
        status = 'WATCH'

    return status, issues


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    ap.add_argument('--run-id', required=True)
    ap.add_argument('--t002', default=None)
    ap.add_argument('--workbook', default='automation/MicroHydroV1_RnD_Export.xlsx')
    ap.add_argument('--out', default=None)
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    run_id = args.run_id

    # infer run number
    m = re.search(r'Run(\d+)', run_id, re.IGNORECASE)
    run_num = m.group(1) if m else 'X'
    version_tag = f"RUN{run_num}" if m else 'RUN'

    t002 = Path(args.t002) if args.t002 else (root/'tests'/'raw'/run_id/'T002_TankRipple_timeseries.csv')
    if not t002.is_absolute():
        t002 = root/t002

    wb = Path(args.workbook)
    if not wb.is_absolute():
        wb = root/wb

    metrics = {
        'run_id': run_id,
        'version_tag': version_tag,
        'release_id': f"R-{run_id.split('_')[0]}",
        'created_at': dt.datetime.now().isoformat(timespec='seconds'),
    }

    # T-002 resonance metrics
    if t002.exists():
        metrics.update(peakiness_metrics(t002))
    else:
        metrics['warnings'] = metrics.get('warnings', []) + ['Missing T-002 timeseries CSV']

    # Workbook metrics
    if wb.exists():
        recs = read_measurements_for_run(wb, run_id)
        if recs.get('_run_col_missing'):
            metrics['warnings'] = metrics.get('warnings', []) + ['Workbook has no Run_ID column; using latest values may mix runs.']

        # Map values
        if 'T-001' in recs:
            metrics['t001_coherence'] = _safe_float(recs['T-001']['value'])
        if 'T-002' in recs:
            metrics['t002_ripple_mm'] = _safe_float(recs['T-002']['value'])
            metrics['t002_baseline_mm'] = _safe_float(recs['T-002'].get('baseline'))
            if metrics.get('t002_ripple_mm') is not None and metrics.get('t002_baseline_mm'):
                b = metrics['t002_baseline_mm']
                rmm = metrics['t002_ripple_mm']
                if b > 0:
                    metrics['t002_reduction_pct'] = (b - rmm) / b * 100.0
        if 'T-003' in recs:
            metrics['t003_drift_hz'] = _safe_float(recs['T-003']['value'])
        if 'T-004' in recs:
            metrics['t004_power_kw'] = _safe_float(recs['T-004']['value'])
    else:
        metrics['warnings'] = metrics.get('warnings', []) + ['Workbook not found']

    status, issues = classify(metrics)
    metrics['status'] = status
    metrics['issues'] = issues

    # Output
    out = Path(args.out) if args.out else (root/'docs'/f'run{run_num}'/f'{version_tag}_Metrics_{run_id}.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(metrics, indent=2) + '\n', encoding='utf-8')
    print('Wrote:', out)
    print('Status:', status)
    if issues:
        print('Issues:')
        for i in issues:
            print(' -', i)


if __name__ == '__main__':
    main()
