#!/usr/bin/env python3
"""Detect parameter drift by comparing current canonical params.json to the last released snapshot.

- Current: cad/params/params.json
- Last release: from the newest ZIP in a given releases directory (or dist/)

Outputs a JSON diff report.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import json
import zipfile

def load_json_bytes(b: bytes):
    return json.loads(b.decode('utf-8'))

def find_latest_zip(folder: Path):
    zips = sorted(folder.glob('*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
    return zips[0] if zips else None

def dict_diff(a, b, prefix=''):
    diffs = []
    keys = set(a.keys()) | set(b.keys())
    for k in sorted(keys):
        pa = a.get(k, '__MISSING__')
        pb = b.get(k, '__MISSING__')
        path = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
        if isinstance(pa, dict) and isinstance(pb, dict):
            diffs.extend(dict_diff(pa, pb, path))
        else:
            if pa != pb:
                diffs.append({'path': path, 'current': pa, 'released': pb})
    return diffs

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    ap.add_argument('--releases-dir', default=None, help='Folder with release ZIPs; default: <root>/dist')
    ap.add_argument('--out', default=None)
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    releases = Path(args.releases_dir).resolve() if args.releases_dir else (root/'dist')

    current_path = root/'cad'/'params'/'params.json'
    if not current_path.exists():
        raise SystemExit('Missing current params.json at cad/params/params.json')

    z = find_latest_zip(releases)
    if not z:
        raise SystemExit(f'No ZIP releases found in: {releases}')

    # read released params.json inside zip
    released = None
    with zipfile.ZipFile(z, 'r') as Z:
        # typical: MicroHydroV1/cad/params/params.json
        candidates = [
            'MicroHydroV1/cad/params/params.json',
            'cad/params/params.json'
        ]
        for c in candidates:
            try:
                released = load_json_bytes(Z.read(c))
                break
            except Exception:
                continue
    if released is None:
        raise SystemExit('Could not find released params.json inside latest ZIP: ' + str(z))

    current = json.loads(current_path.read_text(encoding='utf-8'))

    diffs = dict_diff(current, released)
    report = {
        'latest_zip': str(z),
        'current_params': str(current_path),
        'diff_count': len(diffs),
        'diffs': diffs[:500],
        'note': 'If diff_count is large and unexpected, you may have parameter drift.'
    }

    out = Path(args.out) if args.out else (root/'cad'/'params'/'params_drift_report.json')
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print('Wrote:', out)
    print('Compared against:', z)

if __name__ == '__main__':
    main()
