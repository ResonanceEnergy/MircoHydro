#!/usr/bin/env python3
"""Rename the latest dist release ZIP using run metrics.

Example output name:
MicroHydroV1_Release_RUN3_2026-01-22_TankRipple_PASS_Peak1p47.zip

This is optional. It never mutates file contents, only the filename.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import json
import re

def latest_zip(dist: Path):
    zips = sorted(dist.glob('*.zip'), key=lambda p: p.stat().st_mtime, reverse=True)
    return zips[0] if zips else None

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--dist', default='dist')
    ap.add_argument('--metrics', required=True)
    ap.add_argument('--desc', default='')
    args = ap.parse_args(argv)

    dist = Path(args.dist)
    z = latest_zip(dist)
    if not z:
        raise SystemExit('No ZIP found in dist/')

    m = json.loads(Path(args.metrics).read_text(encoding='utf-8'))
    run_id = m.get('run_id','')
    version = m.get('version_tag','RUN')
    date = (run_id.split('_')[0] if '_' in run_id else '')
    status = m.get('status','WATCH')
    peak = m.get('t002_peakiness', None)

    # sanitize desc
    desc = re.sub(r'[^A-Za-z0-9_-]+','_', args.desc).strip('_')
    peak_s = ''
    if isinstance(peak, (int,float)):
        peak_s = f"Peak{peak:.2f}".replace('.','p')

    parts = ['MicroHydroV1','Release',version,date]
    if desc:
        parts.append(desc)
    parts.append(status)
    if peak_s:
        parts.append(peak_s)
    new_name = '_'.join([p for p in parts if p]) + '.zip'

    new_path = z.with_name(new_name)
    z.rename(new_path)
    print('Renamed to:', new_path)

if __name__ == '__main__':
    main()
