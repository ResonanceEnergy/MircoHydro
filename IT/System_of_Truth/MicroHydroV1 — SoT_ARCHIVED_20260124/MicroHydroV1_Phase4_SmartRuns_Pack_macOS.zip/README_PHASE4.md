# MicroHydroV1 — Phase 4 SmartRuns Pack (macOS)

Phase 4 turns each bench run into a **self‑validated, self‑scored, self‑reported** release.

It builds on Phase 3 (one‑command per‑run pipeline) and the locked-in resonance metric system.

## What you get

### A) Auto‑classification (PASS / WATCH / FAIL)
- Reads the **run’s** measurements (by `Run_ID`) from `automation/MicroHydroV1_RnD_Export.xlsx`.
- Applies acceptance rules:
  - T‑001 coherence ≥ 0.90
  - T‑002 ripple ≤ 0.70 × baseline
  - T‑003 drift ≤ 0.10 Hz
  - T‑004 power 10–12 kW
- Adds resonance context (T‑002 PSD peakiness + dominant Hz) from the T‑002 timeseries.

### B) Auto‑plot + HTML run report
Creates `docs/runN/RUNx_Report_<RunID>.html` that embeds:
- T‑002 PSD plot (if present)
- key metrics + pass/fail
- links to evidence doc + raw folder + preflight JSON

### C) SharePoint tagging strategy (Power Automate)
Because Power Automate can’t easily parse inside ZIPs, Phase 4 generates a **sidecar metrics JSON**:
- `dist/<ReleaseName>.metrics.json`
Upload the ZIP **and** the sidecar JSON to Releases.
Flow updates the ZIP item’s metadata based on the JSON.

### D) Trend visualizer across releases
Scan a folder full of release ZIPs + metrics JSON files and produce timeline plots.

### E) Parameter drift detector
Compares current `cad/params/params.json` to the most recent released params snapshot.

## Install
Unzip into your MicroHydroV1 repo root (same level as `docs/ cad/ automation/ tests/ tools/`).

## Configure (macOS conveniences)
Optionally set:
- `MICROHYDRO_RELEASES_URL` — opens Releases library in browser
- `MICROHYDRO_RELEASES_SYNC_PATH` — local Finder path to a synced Releases library folder; if set, Phase 4 will copy ZIP+metrics there automatically.

Example:
```bash
export MICROHYDRO_RELEASES_URL='https://<tenant>.sharepoint.com/sites/<site>/MicroHydroV1%20%E2%80%94%20Releases'
export MICROHYDRO_RELEASES_SYNC_PATH="$HOME/SharePoint/MicroHydroV1 — Releases"
```

## Usage (recommended)

### 1) Run Phase 3 pipeline (optimize/import/release/evidence)
Use your Phase 3 launcher.

### 2) Run Phase 4 post‑processing
```bash
python3 scripts/phase4/run_phase4.py --root . --run-id YYYY-MM-DD_RunN[_Desc]
```

This creates:
- `docs/runN/RUNx_Metrics_<RunID>.json`
- `docs/runN/RUNx_Report_<RunID>.html`
- `dist/<ReleaseZipName>.metrics.json`
- optional: copies ZIP + JSON to `MICROHYDRO_RELEASES_SYNC_PATH`

### 3) Trend plots (across many releases)
```bash
python3 tools/analytics/trend_releases.py --releases-dir <folder_with_release_zips_and_metrics>
```

## Notes
- Requires that your importer writes a `Run_ID` column (recommended). If missing, the scripts will fall back to newest values but will warn.
