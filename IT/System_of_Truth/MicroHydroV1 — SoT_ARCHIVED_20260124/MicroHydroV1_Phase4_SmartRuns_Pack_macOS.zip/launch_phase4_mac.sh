#!/bin/bash
# MicroHydroV1 Phase 4 Launcher (macOS)
# Usage:
#   chmod +x ./launch_phase4_mac.sh
#   ./launch_phase4_mac.sh YYYY-MM-DD_RunN[_Desc]
set -e
RUNID="$1"
if [ -z "$RUNID" ]; then
  echo "Usage: ./launch_phase4_mac.sh YYYY-MM-DD_RunN[_Desc]"
  exit 1
fi
python3 scripts/phase4/run_phase4.py --root . --run-id "$RUNID" --open
