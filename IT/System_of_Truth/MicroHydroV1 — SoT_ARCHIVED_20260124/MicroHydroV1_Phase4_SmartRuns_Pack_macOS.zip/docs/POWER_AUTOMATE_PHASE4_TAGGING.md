# Power Automate — Phase 4 Tagging (ZIP + sidecar JSON)

## Goal
When you upload a per‑run release ZIP to the **Releases** library, also upload a sidecar JSON file:

- `MicroHydroV1_Release_RUN3_2026-01-22.zip`
- `MicroHydroV1_Release_RUN3_2026-01-22.metrics.json`

The flow reads `.metrics.json`, then updates metadata on the matching `.zip` item.

## Required SharePoint columns (Releases library)
Create columns:
- `Run_ID` (text)
- `Run_Status` (choice: PASS, WATCH, FAIL)
- `Peakiness` (number)
- `Dominant_Hz` (number)
- `Coherence` (number)
- `Ripple_mm` (number)
- `Baseline_mm` (number)
- `Ripple_Reduction_pct` (number)
- `ELC_Drift_Hz` (number)
- `Power_kW` (number)
- `Version Tag` (text)
- `Release ID` (text)

## Flow: On metrics JSON upload
Trigger:
- When a file is created (properties only) in Releases
Condition:
- `File name` ends with `.metrics.json`
Steps:
1) Get file content
2) Parse JSON (use a schema based on example below)
3) Compute the matching ZIP name:
   - replace `.metrics.json` with `.zip`
4) Find file by path / list items:
   - Use "Get files (properties only)" filtered by `FileLeafRef eq '<zipName>'`
5) Update file properties for the ZIP item using parsed fields.
6) (Optional) Post Teams message: `Run_ID`, `Run_Status`, `Peakiness`, link to ZIP.

## Example metrics JSON (schema)
```json
{
  "run_id": "2026-01-22_Run3_TankRipple",
  "version_tag": "RUN3",
  "release_id": "R-2026-01-22",
  "status": "PASS",
  "t001_coherence": 0.945,
  "t002_ripple_mm": 6.8,
  "t002_baseline_mm": 12.5,
  "t002_reduction_pct": 45.6,
  "t002_peakiness": 1.47,
  "t002_dominant_hz": 4.32,
  "t003_drift_hz": 0.062,
  "t004_power_kw": 11.3,
  "created_at": "2026-01-22T12:34:56"
}
```
