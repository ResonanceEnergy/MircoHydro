#!/usr/bin/env python3
"""Trend visualizer across releases.

Inputs: a folder containing:
- release ZIPs named like `MicroHydroV1_Release_<TAG>_<DATE>.zip`
- sidecar JSON files `*.metrics.json`

Outputs:
- `trend_peakiness.png`
- `trend_power.png`
- `trend_summary.csv`

This avoids needing to parse inside ZIPs for Power Automate and keeps analysis easy.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import json
import re
import pandas as pd
import matplotlib.pyplot as plt


def find_metrics(releases_dir: Path):
    rows = []
    for p in releases_dir.rglob('*.metrics.json'):
        try:
            obj = json.loads(p.read_text(encoding='utf-8'))
            obj['_metrics_file'] = str(p)
            rows.append(obj)
        except Exception:
            continue
    return pd.DataFrame(rows)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--releases-dir', required=True)
    ap.add_argument('--out-dir', default=None)
    args = ap.parse_args(argv)

    releases = Path(args.releases_dir)
    out = Path(args.out_dir) if args.out_dir else releases
    out.mkdir(parents=True, exist_ok=True)

    df = find_metrics(releases)
    if df.empty:
        raise SystemExit('No *.metrics.json files found in releases-dir.')

    # Parse run_num and date for sorting
    def run_num(s):
        m = re.search(r'Run(\d+)', str(s), re.IGNORECASE)
        return int(m.group(1)) if m else None

    df['run_num'] = df.get('run_id', '').map(run_num)
    df['created_at'] = pd.to_datetime(df.get('created_at', None), errors='coerce')
    if df['created_at'].isna().all():
        # fallback: sort by run_num
        df = df.sort_values(['run_num'])
    else:
        df = df.sort_values(['created_at','run_num'])

    # Save CSV
    keep_cols = [c for c in [
        'run_id','version_tag','release_id','status','t002_peakiness','t002_dominant_hz',
        't001_coherence','t002_ripple_mm','t002_baseline_mm','t002_reduction_pct',
        't003_drift_hz','t004_power_kw','created_at'
    ] if c in df.columns]
    df[keep_cols].to_csv(out/'trend_summary.csv', index=False)

    # Plot peakiness
    if 't002_peakiness' in df.columns:
        plt.figure(figsize=(10,4))
        plt.plot(df.index, df['t002_peakiness'], marker='o')
        plt.title('T-002 PSD Peakiness (lower is better)')
        plt.xlabel('Run index')
        plt.ylabel('Peakiness (max/median PSD)')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out/'trend_peakiness.png', dpi=200)
        plt.close()

    # Plot power
    if 't004_power_kw' in df.columns:
        plt.figure(figsize=(10,4))
        plt.plot(df.index, df['t004_power_kw'], marker='o', color='green')
        plt.axhspan(10, 12, color='green', alpha=0.08, label='10–12 kW band')
        plt.title('T-004 Power (kW)')
        plt.xlabel('Run index')
        plt.ylabel('Power (kW)')
        plt.grid(True, alpha=0.3)
        plt.legend(loc='best')
        plt.tight_layout()
        plt.savefig(out/'trend_power.png', dpi=200)
        plt.close()

    print('Wrote:', out/'trend_summary.csv')
    if (out/'trend_peakiness.png').exists():
        print('Wrote:', out/'trend_peakiness.png')
    if (out/'trend_power.png').exists():
        print('Wrote:', out/'trend_power.png')


if __name__ == '__main__':
    main()
