# MicroHydroV1 Add-on (macOS) — InitGui with robust BASE resolution
# Fixes: BASE incorrectly resolving to '/' causing missing /icons /macros /QA /Drawings /CFD.
# Install: copy this file into ~/Library/Application Support/FreeCAD/Mod/MicroHydroV1/InitGui.py

import os, sys

def _resolve_base():
    """Return the add-on folder (…/Mod/MicroHydroV1), never '/'."""
    # 1) Explicit override (optional)
    env = os.environ.get('MICROHYDRO_MHV1_BASE', '').strip()
    if env and os.path.isdir(env):
        return os.path.abspath(env)

    # 2) Directory containing this file
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        if os.path.isdir(here):
            return here
    except Exception:
        pass

    # 3) Try to locate by module spec/origin
    try:
        spec = globals().get('__spec__', None)
        origin = getattr(spec, 'origin', None)
        if origin and os.path.exists(origin):
            base = os.path.dirname(os.path.abspath(origin))
            if os.path.isdir(base):
                return base
    except Exception:
        pass

    # 4) Expected macOS user Mod path
    mac_guess = os.path.expanduser('~/Library/Application Support/FreeCAD/Mod/MicroHydroV1')
    if os.path.isdir(mac_guess):
        return os.path.abspath(mac_guess)

    # 5) Search sys.path for a folder ending in /Mod/MicroHydroV1
    for p in list(sys.path):
        if not p:
            continue
        cand = os.path.join(p, 'MicroHydroV1') if p.endswith('Mod') else p
        if cand.endswith(os.sep + 'MicroHydroV1') and os.path.isdir(cand):
            return os.path.abspath(cand)

    # 6) As a last resort, use cwd if it contains expected subfolders
    cwd = os.path.abspath(os.getcwd())
    for sub in ('icons', 'macros', 'QA', 'Drawings', 'CFD'):
        if os.path.isdir(os.path.join(cwd, sub)):
            return cwd

    # Never return '/'
    return cwd if cwd != os.sep else os.path.expanduser('~')

BASE  = _resolve_base()
ICONS = os.path.join(BASE, 'icons')
MACROS= os.path.join(BASE, 'macros')
QA    = os.path.join(BASE, 'QA')
DRAW  = os.path.join(BASE, 'Drawings')
CFD   = os.path.join(BASE, 'CFD')

print('[MHV1][InitGui] Base:', BASE)
for label, path in (('ICONS',ICONS),('MACROS',MACROS),('QA',QA),('DRAWINGS',DRAW),('CFD',CFD)):
    print(f"[MHV1][SELF-TEST] {label}: {'OK' if os.path.exists(path) else 'FAIL'} — {path}")

def _exec_macro(relpath):
    path = os.path.normpath(os.path.join(MACROS, relpath))
    if not os.path.exists(path):
        print('[MHV1][ERROR] Macro missing:', path)
        return
    with open(path, 'r', encoding='utf-8') as f:
        code = f.read()
    exec(compile(code, path, 'exec'), {})

class _MHV1_Cmd_GenerateAll:
    def GetResources(self):
        return {'Pixmap': os.path.join(ICONS,'mhv1_generate.svg'),'MenuText':'Generate All Parts','ToolTip':'Run MicroHydroV1 build_all macro'}
    def IsActive(self): return True
    def Activated(self): _exec_macro('build_all.FCMacro')

class _MHV1_Cmd_ExportAll:
    def GetResources(self):
        return {'Pixmap': os.path.join(ICONS,'mhv1_export.svg'),'MenuText':'Export ALL CAD','ToolTip':'Export STEP/STL/IGES/BREP for all parts'}
    def IsActive(self): return True
    def Activated(self): _exec_macro(os.path.join('scripts','export_all_formats.FCMacro'))

class _MHV1_Cmd_RunQA:
    def GetResources(self):
        return {'Pixmap': os.path.join(ICONS,'mhv1_qa.svg'),'MenuText':'Run QA Suite','ToolTip':'Geometry QA checks'}
    def IsActive(self): return True
    def Activated(self):
        qa = os.path.join(QA,'run_qa_suite.FCMacro')
        if not os.path.exists(qa):
            print('[MHV1][ERROR] QA macro not found:', qa); return
        with open(qa,'r',encoding='utf-8') as f: code=f.read()
        exec(compile(code, qa, 'exec'), {})

class _MHV1_Cmd_GenDrawings:
    def GetResources(self):
        return {'Pixmap': os.path.join(ICONS,'mhv1_drawings.svg'),'MenuText':'Generate Drawings','ToolTip':'TechDraw → PDF/SVG'}
    def IsActive(self): return True
    def Activated(self):
        dm = os.path.join(DRAW,'generate_drawings.FCMacro')
        if not os.path.exists(dm):
            print('[MHV1][ERROR] Drawings macro not found:', dm); return
        with open(dm,'r',encoding='utf-8') as f: code=f.read()
        exec(compile(code, dm, 'exec'), {})
