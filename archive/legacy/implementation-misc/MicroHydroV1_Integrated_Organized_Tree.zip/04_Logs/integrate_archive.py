
#!/usr/bin/env python3
"""Integrate MicroHydroV1 Archive.zip into an organized tree.

What it does:
- Cleans junk (__MACOSX, .DS_Store)
- Copies SharePoint libraries into 01_SharePoint_Libraries
- Deduplicates embedded ZIP packages by SHA-256
- Extracts the base FULL pack, then overlays add-ons (DO_ALL, Calibration/AutoEmbed, RUN3)
- Produces an integration report with conflict (overwrite) list

Usage:
  python3 integrate_archive.py --archive Archive.zip --out Integrated_MicroHydroV1_Tree

"""

from __future__ import annotations
import argparse, os, re, json, shutil, zipfile, hashlib
from pathlib import Path
from datetime import datetime

BAD_FILES = {'.DS_Store'}


def is_junk_path_parts(parts):
    return ('__MACOSX' in parts)


def is_junk_file(name: str, parts=()):
    return (name in BAD_FILES) or name.startswith('._') or is_junk_path_parts(parts)


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def extract_overlay(zip_path: Path, dest_root: Path, conflicts: list, extracted_from: list,
                    prefer_newer=True, strip_prefixes=('MicroHydroV1/',)):
    with zipfile.ZipFile(zip_path, 'r') as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename
            if name.endswith('.DS_Store') or '/__MACOSX/' in name or name.startswith('__MACOSX/') or '/._' in name:
                continue
            for pref in strip_prefixes:
                if name.startswith(pref):
                    name = name[len(pref):]
                    break
            name = name.lstrip('./')
            if not name:
                continue
            out_path = dest_root / name
            out_path.parent.mkdir(parents=True, exist_ok=True)
            src_dt = datetime(*info.date_time).timestamp()
            if out_path.exists() and prefer_newer:
                dst_m = out_path.stat().st_mtime
                if src_dt <= dst_m + 1e-6:
                    continue
                conflicts.append({
                    'file': str(out_path.relative_to(dest_root)),
                    'replaced_by': zip_path.name,
                    'old_mtime': dst_m,
                    'new_mtime': src_dt
                })
            with z.open(info, 'r') as f, open(out_path, 'wb') as o:
                o.write(f.read())
            os.utime(out_path, (src_dt, src_dt))
    extracted_from.append(zip_path.name)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--archive', required=True, help='Path to Archive.zip')
    ap.add_argument('--out', default='Integrated_MicroHydroV1_Tree', help='Output folder')
    args = ap.parse_args(argv)

    src_zip = Path(args.archive).resolve()
    out_root = Path(args.out).resolve()

    if out_root.exists():
        shutil.rmtree(out_root)
    out_root.mkdir(parents=True)

    work = out_root.parent / (out_root.name + '_work')
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)

    with zipfile.ZipFile(src_zip, 'r') as z:
        z.extractall(work / 'extracted')

    extracted = work / 'extracted'

    lib_map = {
        'MicroHydroV1 ΓÇö SoT': 'MicroHydroV1 — SoT',
        'MicroHydroV1 ΓÇö Releases': 'MicroHydroV1 — Releases',
        'MicroHydroV1 ΓÇö Archive': 'MicroHydroV1 — Archive'
    }

    sharepoint_dir = out_root / '01_SharePoint_Libraries'
    sharepoint_dir.mkdir()

    for src_name, dst_name in lib_map.items():
        src = extracted / src_name
        if not src.exists():
            continue
        dst = sharepoint_dir / dst_name
        for p in src.rglob('*'):
            if p.is_dir():
                continue
            if is_junk_file(p.name, p.parts):
                continue
            rel = p.relative_to(src)
            target = dst / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)

    # Copy top-level log doc if present
    log_src = extracted / 'RES_MicroHydroV1_Integration_Log.docx'
    if log_src.exists():
        admin_dir = out_root / '00_Project_Admin'
        admin_dir.mkdir(exist_ok=True)
        shutil.copy2(log_src, admin_dir / log_src.name)

    # Find embedded zip packages
    zip_files = sorted([p for p in extracted.rglob('*.zip') if p.is_file() and not is_junk_file(p.name, p.parts)],
                       key=lambda p: p.name)

    zip_meta = []
    for p in zip_files:
        zip_meta.append({
            'name': p.name,
            'path': str(p),
            'sha256': sha256_file(p),
            'bytes': p.stat().st_size,
            'mtime': p.stat().st_mtime
        })

    from collections import defaultdict
    by_sha = defaultdict(list)
    for r in zip_meta:
        by_sha[r['sha256']].append(r)

    selected, duplicates = [], []
    for sha, items in by_sha.items():
        def score(it):
            return (0 if re.search(r'\s\(\d+\)\.zip$', it['name']) is None else 1, -it['mtime'])
        items_sorted = sorted(items, key=score)
        selected.append(items_sorted[0])
        duplicates.extend(items_sorted[1:])

    selected = sorted(selected, key=lambda x: x['name'].lower())

    pkg_dir = out_root / '03_Packages_Original_Zips'
    pkg_dir.mkdir()
    for it in selected:
        shutil.copy2(Path(it['path']), pkg_dir / it['name'])

    canonical_dir = out_root / '02_Canonical_Working_Tree'
    canonical_dir.mkdir()
    canonical_micro = canonical_dir / 'MicroHydroV1'
    canonical_micro.mkdir()

    base_pack = None
    for it in selected:
        if 'FULL_LOCKED' in it['name'] and 'PressurePa' in it['name']:
            base_pack = it
            break
    if base_pack is None:
        for it in selected:
            if 'FULL' in it['name']:
                base_pack = it
                break

    conflicts, extracted_from = [], []
    if base_pack:
        extract_overlay(pkg_dir / base_pack['name'], canonical_micro, conflicts, extracted_from)

    addon_order = []
    for it in selected:
        n = it['name']
        if base_pack and n == base_pack['name']:
            continue
        if 'DO_ALL' in n:
            addon_order.append((1, n))
        elif 'Calibration' in n or 'AutoEmbed' in n:
            addon_order.append((2, n))
        elif 'RUN3' in n:
            addon_order.append((3, n))
        else:
            addon_order.append((4, n))

    for _, name in sorted(addon_order):
        extract_overlay(pkg_dir / name, canonical_micro, conflicts, extracted_from)

    # overlay loose files from SoT/MicroHydroV1
    loose_root = sharepoint_dir / 'MicroHydroV1 — SoT' / 'MicroHydroV1'
    if loose_root.exists():
        for p in loose_root.rglob('*'):
            if p.is_dir() or is_junk_file(p.name, p.parts):
                continue
            if p.suffix.lower() == '.zip':
                continue
            rel = p.relative_to(loose_root)
            dst = canonical_micro / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists() and p.stat().st_mtime <= dst.stat().st_mtime + 1e-6:
                continue
            if dst.exists():
                conflicts.append({
                    'file': str(rel),
                    'replaced_by': 'LooseSoT',
                    'old_mtime': dst.stat().st_mtime,
                    'new_mtime': p.stat().st_mtime
                })
            shutil.copy2(p, dst)

    logs = out_root / '04_Logs'
    logs.mkdir()
    report = {
        'source_zip': str(src_zip),
        'generated_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
        'selected_zips': [{'name': it['name'], 'sha256': it['sha256'], 'bytes': it['bytes']} for it in selected],
        'duplicate_zips_removed': [{'name': it['name'], 'sha256': it['sha256'], 'bytes': it['bytes']} for it in duplicates],
        'base_pack': base_pack['name'] if base_pack else None,
        'overlay_order': [name for _, name in sorted(addon_order)],
        'extracted_from': extracted_from,
        'conflicts_count': len(conflicts),
        'conflicts_sample': conflicts[:100],
    }
    (logs / 'integration_report.json').write_text(json.dumps(report, indent=2) + '
', encoding='utf-8')

    # cleanup workspace
    shutil.rmtree(work, ignore_errors=True)

    print('Done. Output:', out_root)
    print('Conflicts:', report['conflicts_count'])


if __name__ == '__main__':
    main()
