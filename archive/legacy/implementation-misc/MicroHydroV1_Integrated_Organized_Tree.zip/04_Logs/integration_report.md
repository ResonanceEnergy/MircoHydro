# Integration Report
Generated: 2026-01-22T07:21:30Z

## Selected ZIP packages (deduplicated)
- MicroHydroV1_Calibration_AutoEmbed_AddOn_v0.3.0.zip (11313 bytes)
- MicroHydroV1_DO_ALL_AddOn_v0.3.0.zip (9999 bytes)
- MicroHydroV1_RUN3_AutoFill_Evidence_PLUS_Workbook_T002_v0.3.0.zip (43613 bytes)
- MicroHydroV1_RUN3_AutoFill_Evidence_v0.3.0.zip (40613 bytes)
- MicroHydroV1_RUN3_DoAll_Templates_Plots.zip (39453 bytes)
- MicroHydroV1_v0.3.0_FULL_LOCKED_PressurePa.zip (2065500 bytes)

## Base pack: MicroHydroV1_v0.3.0_FULL_LOCKED_PressurePa.zip

## Overlay order
- MicroHydroV1_DO_ALL_AddOn_v0.3.0.zip
- MicroHydroV1_Calibration_AutoEmbed_AddOn_v0.3.0.zip
- MicroHydroV1_RUN3_AutoFill_Evidence_PLUS_Workbook_T002_v0.3.0.zip
- MicroHydroV1_RUN3_AutoFill_Evidence_v0.3.0.zip
- MicroHydroV1_RUN3_DoAll_Templates_Plots.zip

## Conflicts (overwrites): 32

Sample:
- MANIFEST.json ← MicroHydroV1_Calibration_AutoEmbed_AddOn_v0.3.0.zip
- MANIFEST.json ← MicroHydroV1_RUN3_AutoFill_Evidence_PLUS_Workbook_T002_v0.3.0.zip
- README.md ← LooseSoT
- MANIFEST.json ← LooseSoT
- docs/Jet_Coherence_Procedure.docx ← LooseSoT
- docs/Run_of_Show_Checklist.docx ← LooseSoT
- docs/PASS_A_FULL_RevA.docx ← LooseSoT
- docs/Test_Campaign_Plan.docx ← LooseSoT
- docs/architecture_diagram.png ← LooseSoT
- docs/Tank_Ripple_Procedure.docx ← LooseSoT
- docs/Master_Index.docx ← LooseSoT
- automation/MicroHydroV1_RnD_Export.xlsx ← LooseSoT
- automation/Measurements_Import_Template.csv ← LooseSoT
- automation/Import_Config.json ← LooseSoT
- tests/raw/2026-01-22_Run1_ELCStability/T003_ELCStability_Run1.csv ← LooseSoT
- tests/raw/2026-01-22_Run1_Power/T004_Power_Run1.csv ← LooseSoT
- tests/raw/2026-01-22_Run1_JetCoherence/T001_JetCoherence_Run1.csv ← LooseSoT
- tests/raw/2026-01-22_Run1_TankRipple/T002_TankRipple_Run1.csv ← LooseSoT
- tools/optimize/opt_config.json ← LooseSoT
- tools/optimize/optimize_params.py ← LooseSoT
