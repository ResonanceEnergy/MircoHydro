# Resonance Energy Enterprise Repository

Generated on 2026-01-23.

## Quick start
1. Install Python 3.
2. Run: `python scripts/one_click_installer.py`
3. Find the packaged ZIP in `artifacts/`.

## Source discipline
Technical claims are cited; visionary material is separated into **05_RnD/04_Coherent_Geometry** and does not drive production specifications without validation.
