# Doctrine Handbooks (Mini Handbooks — 4–8 pages)

Last updated: 2026-01-22

Render PDFs (manual):
```bash
python3 scripts/render_handbooks.py
```

## Handbooks

- **HB-01** — Turbine Selection Doctrine (Crossflow-first)  \
  Folder: `HB-01_Turbine_Selection/`  \
  Status: **Draft**
- **HB-02** — Intake & Debris Management (Run-of-River, Water-kind)  \
  Folder: `HB-02_Intake_Debris/`  \
  Status: **Draft**
- **HB-03** — Penstock & Headloss Design (≤10% Loss Standard)  \
  Folder: `HB-03_Penstock_Headloss/`  \
  Status: **Draft**
- **HB-04** — Hydraulic Ram Pump Design & Tuning  \
  Folder: `HB-04_Hydram_Tuning/`  \
  Status: **Draft**
- **HB-05** — Controls, Blackstart & SCADA (Microgrid Backbone)  \
  Folder: `HB-05_Controls_SCADA/`  \
  Status: **Draft**
- **HB-06** — Commissioning & Acceptance Testing (FAT → SAT)  \
  Folder: `HB-06_Commissioning_FAT_SAT/`  \
  Status: **Draft**

## Tagline
Tagline is TBD (see branding/taglines/TAGLINES_MASTER.md).
