# Founding Statement
